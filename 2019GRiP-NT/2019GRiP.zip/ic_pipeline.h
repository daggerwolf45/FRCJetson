#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "GripPipeline.h"
#include <ctime>
#include <iostream>
#include <fstream>

#include <chrono>
#include <cstdio>
#include <thread>

#include <networktables/NetworkTable.h>
#include <ntcore.h>
#include <cscore.h>

using namespace cv;
using namespace std;

class ICPipeline {
	private:
	
	public:
		ICPipeline();

};


