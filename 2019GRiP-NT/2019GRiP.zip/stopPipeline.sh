#!/bin/bash
touch /home/nvidia/FRCJetson/2019GRiP/build/ic_pipeline.stop
exit
